def sum(num1, num2):
    pass

print("덧셈 연산을 하겠습니다.")

if sum(1,2):
    pass
