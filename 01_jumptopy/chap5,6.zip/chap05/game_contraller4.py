from game.sound.echo import *
from game.graphic.render import render_test

echo_test()
render_test()