import game.sound.echo

game.sound.echo.echo_test()

