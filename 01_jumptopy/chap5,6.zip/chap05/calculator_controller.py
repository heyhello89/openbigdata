import mod1

print(mod1.sum(3,4))
# print(mod1,sum(3,'4'))
print(mod1.safe_sum(3,'4'))
print(mod1.safe_sum(3,4))
