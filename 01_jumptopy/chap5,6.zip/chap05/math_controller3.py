import mod3

print(mod3.PI)
a=mod3.Math()
print(a.solv(2))

print(mod3.sum(mod3.PI, 4.4))