from mod1 import sum, safe_sum

print(sum(3,4))
print(sum(3,4))
print(sum(3,4))
# print(sum(3,'4'))
# print(mod1.safe_sum(3,'4'))
# print(mod1.safe_sum(3,4))
print(safe_sum(3,4))
