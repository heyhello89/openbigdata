class Restourant:

    def __init__(self,type):
        self.type=type

    def greet(self):
        print("어서오세요.")

    def menu(self):
        print(" ")