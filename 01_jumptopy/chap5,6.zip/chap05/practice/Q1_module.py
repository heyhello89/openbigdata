from calculator import Calculator
cal1=Calculator([1,2,3,4,5])
print(cal1.sum())
print(cal1.avg())