f=open('memo2.txt', 'a')
f.write("Hello World")
f.close()